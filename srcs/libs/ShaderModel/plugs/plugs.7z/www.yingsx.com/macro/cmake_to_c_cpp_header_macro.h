﻿#ifndef WWW_YINGSX_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_YINGSX_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.yingsx.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.yingsx.com"

#endif // WWW_YINGSX_COM_HEADER_MACRO_H_H_HEAD__FILE__
