﻿#ifndef WWW_121DS_CC_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_121DS_CC_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.121ds.cc.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.121ds.cc"

#endif // WWW_121DS_CC_HEADER_MACRO_H_H_HEAD__FILE__
