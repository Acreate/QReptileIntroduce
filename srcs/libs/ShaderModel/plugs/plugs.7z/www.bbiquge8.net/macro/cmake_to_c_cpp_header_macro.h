﻿#ifndef WWW_BBIQUGE8_NET_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_BBIQUGE8_NET_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.bbiquge8.net.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"http://www.bbiquge8.net"

#endif // WWW_BBIQUGE8_NET_HEADER_MACRO_H_H_HEAD__FILE__
