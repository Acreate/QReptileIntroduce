﻿#ifndef WWW_KANSHULA4_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_KANSHULA4_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.kanshula4.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.kanshula4.com"

#endif // WWW_KANSHULA4_COM_HEADER_MACRO_H_H_HEAD__FILE__
