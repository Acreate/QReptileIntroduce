﻿#ifndef WWW_BIQUDUWX_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_BIQUDUWX_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.biquduwx.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"http://www.biquduwx.com"

#endif // WWW_BIQUDUWX_COM_HEADER_MACRO_H_H_HEAD__FILE__
