﻿#ifndef CMAKE_TO_C_CPP_HEADER_ENV_H_H_HEAD__FILE__
#define CMAKE_TO_C_CPP_HEADER_ENV_H_H_HEAD__FILE__
#pragma once

#define qt_version u8"6.8.0"
#define Builder_Tools_Clang 0
#define Builder_Tools_GNU 0
#define Builder_Tools_MSVC 1

#define is_exe false

#define Cmake_Project_Name u8"www.xs5300.net"
#define Project_Run_bin u8"D:/userCodes/qt/QReptileIntroduce/builder/Debug_x64_MSVC/"
#define Project_Plug_bin u8"D:/userCodes/qt/QReptileIntroduce/builder/Debug_x64_MSVC//plug_lib"
#define Cmake_Executable_Suffix u8".exe"
#define Cmake_Shared_Library_Suffix u8".dll"
#define project_type u8"MODULE_LIBRARY"

#define Cache_Path_Dir u8"D:/userCodes/qt/QReptileIntroduce/builder/Debug_x64_MSVC/write_cache/"

#endif // CMAKE_TO_C_CPP_HEADER_ENV_H_H_HEAD__FILE__
