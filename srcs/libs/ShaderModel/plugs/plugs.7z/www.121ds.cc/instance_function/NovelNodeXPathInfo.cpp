﻿#include "NovelNodeXPathInfo.h"
cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_type_get_novels_node_xpath = QString( QObject::tr( u8R"(div[@class='cf' @id='sitebox' ]/dl)" ) ).toStdWString( );

cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_root_get_type_xpath = QString( QObject::tr( u8R"(div[@class='hd']/ul/li/a)" ) ).toStdWString( );

cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_type_get_type_next_xpath = QString( QObject::tr( u8R"(div[@class="pages"]/ul/li/a[@class="none"])" ) ).toStdWString( );
