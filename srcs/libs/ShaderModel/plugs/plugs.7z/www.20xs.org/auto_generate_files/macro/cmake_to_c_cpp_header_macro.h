﻿#ifndef WWW_20XS_ORG_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_20XS_ORG_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterface_iid	"www.20xs.org.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.20xs.org"

#endif // WWW_20XS_ORG_HEADER_MACRO_H_H_HEAD__FILE__
