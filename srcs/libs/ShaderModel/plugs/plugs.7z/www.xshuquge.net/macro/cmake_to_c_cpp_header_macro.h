﻿#ifndef WWW_XSHUQUGE_NET_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_XSHUQUGE_NET_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.xshuquge.net.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"http://www.xshuquge.net"

#endif // WWW_XSHUQUGE_NET_HEADER_MACRO_H_H_HEAD__FILE__
