﻿#include "NovelNodeXPathInfo.h"

cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_type_get_novels_node_xpath = QString( QObject::tr( u8R"(div[@class="l"]/ul/li/)" ) ).toStdWString( );
cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_root_get_type_xpath = QString( QObject::tr( u8R"(div[@class="nav"]/ul/li/a)" ) ).toStdWString( );
cylHtmlTools::HtmlString instance_function::NovelNodeXPathInfo::novels_type_get_type_next_xpath = QString( QObject::tr(u8R"(div[@class="pagelink" @id="pagelink"]/a[@class="next"])") ).toStdWString( );
