﻿#ifndef WUJIXSW_ORG_HEADER_MACRO_H_H_HEAD__FILE__
#define WUJIXSW_ORG_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"wujixsw.org.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"http://wujixsw.org"

#endif // WUJIXSW_ORG_HEADER_MACRO_H_H_HEAD__FILE__
