﻿#ifndef WWW_X81ZW_IO_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_X81ZW_IO_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.x81zw.io.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.x81zw.io"

#endif // WWW_X81ZW_IO_HEADER_MACRO_H_H_HEAD__FILE__
