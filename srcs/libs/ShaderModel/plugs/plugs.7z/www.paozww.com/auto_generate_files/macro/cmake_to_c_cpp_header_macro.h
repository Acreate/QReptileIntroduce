﻿#ifndef WWW_PAOZWW_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_PAOZWW_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterface_iid	"www.paozww.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.paozww.com"

#endif // WWW_PAOZWW_COM_HEADER_MACRO_H_H_HEAD__FILE__
