﻿#ifndef WWW_XS5300_NET_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_XS5300_NET_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterface_iid	"www.xs5300.net.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"http://www.xs5300.net"

#endif // WWW_XS5300_NET_HEADER_MACRO_H_H_HEAD__FILE__
