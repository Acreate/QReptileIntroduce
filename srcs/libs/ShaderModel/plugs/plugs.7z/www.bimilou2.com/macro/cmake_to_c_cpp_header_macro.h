﻿#ifndef WWW_BIMILOU2_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_BIMILOU2_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.bimilou2.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.bimilou2.com"

#endif // WWW_BIMILOU2_COM_HEADER_MACRO_H_H_HEAD__FILE__
