﻿#ifndef WWW_AHFGB_COM_HEADER_MACRO_H_H_HEAD__FILE__
#define WWW_AHFGB_COM_HEADER_MACRO_H_H_HEAD__FILE__
#pragma once

#define IRequestNetInterfaceExtend_iid	"www.ahfgb.com.json.IRequestNetInterfaceExtend"
#define GET_URL	u8"https://www.ahfgb.com"

#endif // WWW_AHFGB_COM_HEADER_MACRO_H_H_HEAD__FILE__
